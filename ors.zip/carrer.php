<?php

?>
<html>
<head>
<title>TESTING </title>
</head>
 <meta charset="UTF-8">
    <link rel="stylesheet" href="css/w3.css">



<div id="wrapper">

    <header id="header" class="clearfix" role="banner">
    
<hgroup>
<style>
h1 {text-align: center;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
            
<h3><b><span style="color:blue;">(Teaching Staff)</span> </b> </h3>   
</hgroup>

<hgroup>
<style>
h3{text-align: center;}
h2{text-align: center;}
</style>


<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> </hgroup>

<div id="main" class="clearfix">

	<!-- Navigation -->
   <div class="w3-down">
  <div class="w3-row w3-padding w3-white">
    <div class="w3-col s3">
      <a href="index.php" class="w3-btn-block w3-hover-red">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="notice.php" class="w3-btn-block w3-hover-red">NOTICE</a>
    </div>
    <div class="w3-col s3">
      <a href="carrer.php" class="w3-btn-block w3-hover-red">CARRERS</a>
    </div>
    <div class="w3-col s3">
      <a href="contact.php" class="w3-btn-block w3-hover-red">CONTACT</a>
    </div>
  </div>
</div>
    

	
<div class="w3-container">
  <h2>NOTICE</h2>

  <table class="w3-table-all w3-hoverable">
    <thead>
      <tr class="w3-light-grey">
        <th>Title</th>
        <th>Posted Date</th>
        <th>Last Date</th>
      </tr>
    </thead>
    <tr>
      <td>Recruitment for Project Fellow - Dept. of Biochemistry &amp; Mol. Biology<img border=0 src='./new.gif'/></td>
      <td>19-10-2016</td>
      <td>02-11-2016&nbsp;&nbsp;<a href="instruction.php"><img src='./Apply-Here.gif' width=92px/></td>
    </tr>
    <tr>
      <td>Recruitment of SRF/JRF/TA - Dept. of Biotechnology<img border=0 src='./new.gif'/></td>
      <td>13-10-2016</td>
      <td>31-10-2016&nbsp;&nbsp;<a href="instruction.php"><img src='./Apply-Here.gif' width=92px/></td>
    </tr>
    
  </table>
</body>
</html>