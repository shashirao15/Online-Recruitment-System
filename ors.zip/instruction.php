<?php
session_start();

?>
<html>
<head>
<title>INSTRUCTIONS </title>
</head>
 <meta charset="UTF-8">
   <link rel="stylesheet" href="css/w3.css"> 
	

<div id="wrapper">

    <header id="header" class="clearfix" role="banner">
    
<hgroup>
<style>
h3{text-align: center;}
h1 {text-align: center;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
   <h3><b><span style="color:blue;">(Teaching Staff)</span> </b> </h3>            

</hgroup>

<hgroup>
<style>
h2{text-align: center;}
</style>


<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> </hgroup>
<div class="w3-down">
  <div class="w3-row w3-padding w3-white">
    <div class="w3-col s3">
      <a href="index.php" class="w3-btn-block w3-hover-red">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="notice.php" class="w3-btn-block w3-hover-red">NOTICE</a>
    </div>
    <div class="w3-col s3">
      <a href="carrer.php" class="w3-btn-block w3-hover-red">CARRERS</a>
    </div>
    <div class="w3-col s3">
      <a href="contact.php" class="w3-btn-block w3-hover-red">CONTACT</a>
    </div>
  </div>
</div>
	
    <div class="w3-container">
  <h2><u>INSTRUCTIONS FOR FILLING THE ONLINE APPLICATION FORM</u></h2>
  
<ul>
                 
	<li>Candidates  are directed to fill <u><strong>ONLY ONE</strong></u> Application Form for one position.</li>
	
        <li>E-mail ID and Mobile Number furnished must remain valid for at least one year from the date of application. Under no circumstances, he/she should share/mention registration no. to any other person. In case, a candidate does not have a valid personal email ID, he/she should create his/her new Email ID before applying Online.</li>
       
        <li> Candidates must possess the prescribed minimum qualification and fulfill all eligibility conditions/criteria for the Discipline Applied.</li>
        <li> Before applying online a candidate will be required to have a scanned (digital) image in JPG/JPEG format, of his recent Pass-Port Size Photograph (less than 500 KB) and Signature (less than 200 KB) as per the specifications given on the website. Candidates should first scan their photograph and signature and ensure that both the photograph and signature are saved on the PC/Laptop/Other Media.</li>
       
		<li>The Online Application involves the following process: Registration/Login, Personal and Educational Details, Experience Details, Uploading of Photograph and Signature, Payment &amp; Final Submission.</li>
		
		<li>There is a prescribed fee for Online Application Form. Candidates will be directed for Online Payment once the form is completely filled. Candidate is requested to keep his/her Credit Card/ Debit card/ Net Banking details ready for the same. Candidates are required to carefully go through the Instructions for filling Online Application. Candidates while using the Internet Payment Gateway services are required to pay Service Charges as prescribed in the Instruction or by the Internet Payment Gateway.</li>
		<li>  If the candidates faces any difficulty while submitting the online application contact Helpline <strong>Email ID &ndash; <a href="mailto:employment@pondiuni.co.in">employment@pondiuni.co.in </a></strong></li>
       
		<li><a href="3375714_API-4th-Amentment-Regulations-2016_2.pdf"><span style="color: rgb(255, 0, 0);">UGC (Minimum Qualifications for Appointment of Teachers and other Academic Staff in Universities and Colleges and Measures for the Maintenance of Standards in Higher Education) (4th Amendment), Regulations, 2016.<img border=0 src='./important.gif'width=72px/></span></a></p><br><br>
  </ul>
  <div class="w3-container">
  <h2><u>IMPORTANT EVENTS and DATES</u></h2>

  <table class="w3-table-all w3-hoverable">
    <tr>
      <td>1.</td>
      <td>Commencement of online registration of application</td>
      <td>21-10-2016</td>
    </tr>
    <tr>
      <td>2.</td>
      <td>Closure of registration application</td>
      <td>01-11-2016</td>
    </tr>
	</table>
   <br>
   
    <br> <br> 
   <div>
  
 <center> <input type="button" class="w3-btn w3-red" value="Click here for New Registration" onclick="location='Register Page.php'"/>
  <!--<input type="button" class="w3-btn w3-red" value="Login for Already Registered Candidates" onclick="location='login.php'"/>-->
  <button onclick="document.getElementById('id01').style.display='block'" class="w3-btn w3-red" style="width:auto;">Login for Already Registered Candidates</button></center>
</div>
<style>
/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}




.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)}
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)}
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
<body>




<div id="id01" class="modal">
  
  <form method="post" class="modal-content animate">
   

    <div class="container">
      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name='username' required>

      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name='password' required>
        
      <button type='submit' name='login'>Login</button>
      
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>



	  <br> <br> <br>
  
           
</body>
</html>
<?php
mysql_connect("localhost","root","");
mysql_select_db("users_db");

if(isset($_POST['login'])) {

	$user_name = $_POST['username'];
	$user_password = $_POST['password'];  
	
	$check_user = "select * from users where username='$user_name' AND password='$user_password'";
	
	$run = mysql_query($check_user);
	
	if(mysql_num_rows($run)>0) {
		
		$_SESSION['username']=$user_name;
		
		echo "<script>window.open('test.php','_self')</script>";
	}
	else {
		echo "<script>alert('Usrname or Password is Incorrect')</script>";
	}
}





?>