
<!DOCTYPE>
<html lang ="en">
<head>
	<title>Image upload</title>
</head>
<body>
<h3>Image Upload</h3>

<form method="post" action="image.php" enctype="multipart/form-data">
File:
<input type="file" name="image"> <input type="submit" value="Upload">
</form>

<?php
//connect to database
mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db("users_db") or die(mysql_error());

//file properties
$file = $_FILES['image']['tmp_name'];
 
if (!isset($file))
	echo "Please select an image.";
else 
{
$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$image_name = addslashes($_FILES['image']['name']);
$image_size = getimagesize($_files['image']['tmp_name']);

if ($image_size==FALSE)
	echo "That is not an image.";
else
{
	
}
}



?>

 
</body>
</html>
