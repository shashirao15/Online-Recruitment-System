<html>
<head>
<title>TESTING </title>
</head>
 <meta charset="UTF-8">
    <link rel="stylesheet" href="css/w3.css">


<div id="wrapper">

    <header id="header" class="clearfix" role="banner">
    
<hgroup>
<style>
h1 {text-align: center;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
            

</hgroup>

<hgroup>
<style>

h2{text-align: center;}
</style>


<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> </hgroup>

<div id="main" class="clearfix">

	<!-- Navigation -->
   <div class="w3-down">
  <div class="w3-row w3-padding w3-white">
    <div class="w3-col s3">
      <a href="index.php" class="w3-btn-block w3-hover-red">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="notice.php" class="w3-btn-block w3-hover-red">NOTICE</a>
    </div>
    <div class="w3-col s3">
      <a href="carrer.php" class="w3-btn-block w3-hover-red">CARRERS</a>
    </div>
    <div class="w3-col s3">
      <a href="contact.php" class="w3-btn-block w3-hover-red">CONTACT</a>
    </div>
  </div>
</div>
<div class="w3-center w3-padding-64" id="contact">
    <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Registeration</span>
  </div>

    <form method='post' action='' class="w3-container">
    <div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>Username*</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Enter Username" name='username'></center>
    </div>
    
  <div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>Password*</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="password"placeholder="Enter Password" name='password'></center>
    </div>
	<div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>Password Again*</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="password"placeholder="Enter Password Again" name='password_again'></center>
    </div>
	<div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>First Name*</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Enter First name" name='first_name'></center>
    </div>
	<div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>Last Name</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Enter Lastname" name='last_name'></center>
    </div>
<div class="w3-group">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><b>Email*</b></label>
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Enter Username" name='email'></center>
    </div>
  
    <center> <button type='submit' name='submit'class="w3-btn w3-red w3-btn-block w3-padding-12"style="width:50%" value="Register">Register</button></center>
	
  </form>
<center><button onclick="location='instruction.php'" class="w3-btn w3-red" style="width:auto;">Login</button></center>
</div>
</body>
    <h2><span style="color: rgb(255, 0, 0);">Note:Feilds with * are mandatory to be filled.</h2></span>
    
 </html>

<?php

mysql_connect("localhost","root","");
mysql_select_db("users_db");

	if(isset($_POST['submit'])) {
		
		 $user_name = $_POST['username'];
		 $user_password = $_POST['password'];
		 $user_password_again = $_POST['password_again'];
		 $user_fname = $_POST['first_name'];
		 $user_lname = $_POST['last_name'];
		 $user_email = $_POST['email'];
		
		if ($user_name==''){
			echo "<script>alert('Please enter your username!')</script>";
			exit();
		}
		
		if (preg_match("/\\s/", $_POST['username']) == true) {
			echo "<script>alert(Your username must not contain any spaces.')</script>";
		}
		
		
		if (strlen($_POST['password']) < 6) {
			echo "<script>alert('Your password must be at least 6 characters!')</script>";	
			exit();
		}
		if ($_POST['password'] !== $_POST['password_again']) {
			echo "<script>alert('Your password do not match')</script>";
		}
		if ($user_fname==''){
			echo "<script>alert('Please enter your First name!')</script>";
			exit();
		}
		
		if ($user_lname==''){
			echo "<script>alert('Please enter your Last name!')</script>";
			exit();
		}
		
		if ($user_email==''){
			echo "<script>alert('Please enter your Email!')</script>";
			exit();
		}
		
		if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
		echo "<script>alert('A valid email address is required')</script>";	
		exit();
		}
		
		$check_email = "select * from users where email='$user_email'";
	 	
		$run = mysql_query($check_email);
		
		if(mysql_num_rows($run)>0) {
		echo "<script>alert('Email $user_email is already is in used. Try other email!')</script>";
		exit();
		}
		
		$check_username = "select * from users where username='$user_name'";
	 	
		$run = mysql_query($check_username);
		
		if(mysql_num_rows($run)>0) {
		echo "<script>alert('Username $user_name is already is in used. Try other username!')</script>";
		exit();
		}
		
		$query = "insert into users (username,password,first_name,last_name,email) values ('$user_name','$user_password','$user_fname','$user_lname','$user_email')";
		if(mysql_query($query)){
			
			echo "<script>alert('You have been Regisered Successfully!')</script>";
		}
	}
?> 



