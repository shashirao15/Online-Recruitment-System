<?php
session_start();
session_destroy();
include 'genearal.php';
include 'academic.php';
?>
<?php //echo $_SESSION['username'];?>
<html>
<head>
<title>TESTING </title>
</head>
 <meta charset="UTF-8">
    <link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">

<div id="wrapper">

    <header id="header" class="clearfix" role="banner">
    
<hgroup>
<style>
h1 {text-align: center;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
            

</hgroup>

<hgroup>
<style>

h2{text-align: center;}
</style>


<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> </hgroup>


<style>

.city {display:none;}
</style>
<body>
<marquee><b><span style="color:#FF0000;">Last date of filling the application form is on 20.11.2016</b></span></marquee>
<div class="w3-container">
<ul class="w3-ul">
  
    <a href="instruction.php" class="w3-large" ><i class="fa fa-home"></i> Logout</a>
   
    
  </ul>
  <ul class="w3-navbar w3-black">
    <li><a href="javascript:void(0)" class="tablink" onclick="openCity(event, 'generald');">Genearal Details</a></li>
    <li><a href="javascript:void(0)" class="tablink" onclick="openCity(event, 'quali');">Qualifications</a></li>
    <li><a href="javascript:void(0)" class="tablink" onclick="openCity(event, 'work');">Work Experience</a></li>
	<li><a href="javascript:void(0)" class="tablink" onclick="openCity(event, 'declaration');">Declaration</a></li>
  </ul>

  <div id="generald" class="w3-container w3-border city">
	<div class="w3-container w3-section w3-border w3-topbar w3-bottombar w3-round-xlarge w3-border-red w3-margin-left w3-margin-right">
	<div class="w3-panel w3-grey w3-round-xlarge">
    <p>Personal Details</p>
	</div>
  <table class="w3-table">
    <form method="post" action=''>
    <tr>
      <td>Name of Applicant:</td>
      <td nowrap="nowrap"><input type="text" name="first_name" value="" class="input lettersonly required" name="first_name" style="text-transform:uppercase" maxlength="40" placeholder="First Name"  />								<input type="text" name="middle_name" value="" class="input lettersonly" name="middle_name" style="text-transform:uppercase" maxlength="40" placeholder="Middle Name"  />								<input type="text" name="last_name" value="" class="input lettersonly" name="last_name" style="text-transform:uppercase" maxlength="40" placeholder="Last Name"  />
                            </td>
      
    </tr>
    <tr>
      <td>Post Applied For:</td>
      <td><select class="w3-select" name="option_pa" style="width:20%">
  <option value="Select">Select your Post</option>
  <option value="Professor">Professor</option>
  <option value="Associate Professor">Associate Professor</option>
  <option value="Assistant Professor">Assistant Professor</option>
  <option value="DEAN">DEAN</option>
  <option value="HOD">HOD</option>
</select></td>
      
    </tr>
    <tr>
      <td>School/Deaprtment</td>
      <td><select class="w3-select" name="option_dept" style="width:40%">
  <option value="Deaprtment">Select School/Deaprtment</option>
  <option value="School of Management">School of Management</option>
  <option value="Ramanaujan School of Mathematical Sciences">Ramanaujan School of Mathematical Sciences</option>
  <option value="School of Engineering & Technology">School of Engineering & Technology</option>
  <option value="School of Physical , Chemical and Applied Sciences">School of Physical , Chemical and Applied Sciences</option>
  <option value="School of Life Sciences">School of Life Sciences</option>
  <option value="School of Humanities">School of Humanities</option>
  <option value="School of Social Sciences and International Studies">School of Social Sciences and International Studies</option>
</select></td>
      
    </tr>
	<tr>
      <td>Father's Name:</td>
      <td nowrap="nowrap"><input type="text" name="ffirst_name" value="" class="input lettersonly required" name="first_name" style="text-transform:uppercase" maxlength="40" placeholder="First Name"  />								<input type="text" name="fmiddle_name" value="" class="input lettersonly" name="middle_name" style="text-transform:uppercase" maxlength="40" placeholder="Middle Name"  />								<input type="text" name="flast_name" value="" class="input lettersonly" name="last_name" style="text-transform:uppercase" maxlength="40" placeholder="Last Name"  />
                            </td>
      
    </tr>
	<tr>
      <td>Mother's Name:</td>
      <td nowrap="nowrap"><input type="text" name="mfirst_name" value="" class="input lettersonly required" name="first_name" style="text-transform:uppercase" maxlength="40" placeholder="First Name"  />								<input type="text" name="mmiddle_name" value="" class="input lettersonly" name="middle_name" style="text-transform:uppercase" maxlength="40" placeholder="Middle Name"  />								<input type="text" name="mlast_name" value="" class="input lettersonly" name="last_name" style="text-transform:uppercase" maxlength="40" placeholder="Last Name"  />
                            </td>
      
    </tr>
	<tr>
      <td>Date Of Birth:</td>
	  <td><input type="date" name="dob"><td>
</tr>
<tr>
      <td>Nationality:</td>
      <td><input type="text" name="nationality"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
      
    </tr>
	
	<tr>
      <td>Religion:</td>
      <td><select class="w3-select" name="option_religion" style="width:20%">
  <option value="Select">--Select--</option>
  <option value="Hinduism">Hinduism</option>
  <option value="Buddhism">Buddhism</option>
  <option value="Jainism">Jainism</option>
  <option value="Sikhism">Sikhism</option>
</select></td></tr>

<tr>
<td>Gender:</td>
<td><input class="w3-radio" type="radio" name="gender" value="male" checked>
<label class="w3-validate">Male</label>

<input class="w3-radio" type="radio" name="gender" value="female">
<label class="w3-validate">Female</label>
</td>
</tr>

<tr>
<td>Marital Status:</td>
<td><input class="w3-radio" type="radio" name="martial" value="single" checked>
<label class="w3-validate">Single</label>

<input class="w3-radio" type="radio" name="martial" value="married">
<label class="w3-validate">Married</label>

<input class="w3-radio" type="radio" name="martial" value="widow">
<label class="w3-validate">Widow</label>
</td>
</tr>

<tr>
<td>Category:</td>
<td><input class="w3-radio" type="radio" name="category" value="general" checked>
<label class="w3-validate">Un-Reserved(General)</label>

<input class="w3-radio" type="radio" name="category" value="obc">
<label class="w3-validate">OBC</label><br>

<input class="w3-radio" type="radio" name="category" value="st">
<label class="w3-validate">ST</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input class="w3-radio" type="radio" name="category" value="sc">
<label class="w3-validate">SC</label>
</td>
</tr>
<tr>
      <td>Are you a PHP <br>(Physically Handicapped Person):</td>
      <td><select class="w3-select" name="option_php" style="width:20%">
  <option value="">--Select--</option>
  <option  value="YES">YES</option>
  <option  value="NO">NO</option>
</select></td></tr>

<tr>
      <td>Email Address:</td>
      <td><input type="text" name="email_add"  class="input lettersonly required"   maxlength="60" /></td>
      
    </tr>
	
	<tr>
      <td>Confirm Email Address:</td>
      <td><input type="text" name="cnf_email"  class="input lettersonly required"   maxlength="60" /></td>
      
    </tr>
	
	<tr>
      <td>Mobile Number:</td>
      <td><input type="text" name="mnumber"  class="input lettersonly required"   maxlength="10" /></td>
      </tr>
	  
  </table>
</div>
<div class="w3-container w3-section w3-border w3-topbar w3-bottombar w3-round-xlarge w3-border-red w3-margin-left w3-margin-right">
<div class="w3-panel w3-grey w3-round-xlarge">
    <p>Permanent Address</p>
  </div>
  <table class="w3-table">
  <tr>
      <td>Address Line 1:</td>
      <td><input type="text" name="pline1"  class="input lettersonly required" style="text-transform:uppercase"   maxlength="50" /></td>
      </tr>
	  <tr>
      <td>Address Line 2:</td>
      <td><input type="text" name="pline2"  class="input lettersonly required" style="text-transform:uppercase"   maxlength="50" /></td>
      </tr>
	  <tr>
      <td>City:</td>
      <td><input type="text" name="pline3"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="50" /></td>
      </tr>
	  
	  <tr>
      <td>Country:</td>
      <td><select class="w3-select" name="p_country" style="width:30%">
  <option value="">--Select--</option>
  <option  value="india">India</option>
  </select>

      <td>State:</td>
      <td><select class="w3-select" name="p_state" style="width:40%">
  <option value="Select">--Select--</option>
  <option  value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
  <option  value="Andhra Pradesh">Andhra Pradesh</option>
  <option  value="Arunachal Pradesh">Arunachal Pradesh</option>
  <option  value="Assam">Assam</option>
  <option  value="Bihar">Bihar</option>
  <option  value="Chandigarh">Chandigarh</option>
  <option  value="Chhattisgarh">Chhattisgarh</option>
  <option  value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
  <option  value="Daman and Diu">Daman and Diu</option>
  <option  value="New Delhi">New Delhi</option>
  <option  value="Goa">Goa</option>
  <option  value="Gujarat">Gujarat</option>
  <option  value="Haryana">Haryana</option>
  <option  value="Himachal Pradesh">Himachal Pradesh</option>
  <option  value="Jammu and Kashmir">Jammu and Kashmir</option>
  <option  value="Jharkhand">Jharkhand</option>
  <option  value="Karnataka">Karnataka</option>
  <option  value="Kerala">Kerala</option>
  <option  value="Lakshadweep">Lakshadweep</option>
  <option  value="Madhya Pradesh">Madhya Pradesh</option>
  <option  value="Maharashtra">Maharashtra</option>
  <option  value="Manipur">Manipur</option>
  <option  value="Meghalaya">Meghalaya</option>
  <option  value="Mizoram">Mizoram</option>
  <option  value="Nagaland">Nagaland</option>
  <option  value="Odisha">Odisha</option>
  <option  value="Puducherry">Puducherry</option>
  <option  value="Punjab">Punjab</option>
  <option  value="Rajasthan">Rajasthan</option>
  <option  value="Sikkim">Sikkim</option>
  <option  value="Tamil Nadu">Tamil Nadu</option>
  <option  value="Telangana">Telangana</option>
  <option  value="Tripura">Tripura</option>
  <option  value="Uttar Pradesh">Uttar Pradesh</option>
  <option  value="Uttarakhand">Uttarakhand</option>
  <option  value="West Bengal">West Bengal</option>
  </select></td></td>
  </tr>
</tr>
 <tr>
      <td>PinCode:</td>
      <td><input type="text" name="p_pin"  class="input lettersonly required"   maxlength="6" /></td>
      </tr>
	  </table>
	  <table>
	  <div class="w3-panel w3-grey w3-round-xlarge">
    <p>Correspondence Address</p>
  </div>
  <table class="w3-table">
  <tr>
      <td>Address Line 1:</td>
      <td><input type="text" name="cline1"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="50" /></td>
      </tr>
	  <tr>
      <td>Address Line 2:</td>
      <td><input type="text" name="cline2"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="50" /></td>
      </tr>
	  <tr>
      <td>City:</td>
      <td><input type="text" name="cline3"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="50" /></td>
      </tr>
	  
	  <tr>
      <td>Country:</td>
      <td><select class="w3-select" name="c_country" style="width:30%">
  <option value="">--Select--</option>
  <option  value="india">India</option>
  </select>

      <td>State:</td>
      <td><select class="w3-select" name="c_state" style="width:40%">
  <option value="Select">--Select--</option>
  <option  value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
  <option  value="Andhra Pradesh">Andhra Pradesh</option>
  <option  value="Arunachal Pradesh">Arunachal Pradesh</option>
  <option  value="Assam">Assam</option>
  <option  value="Bihar">Bihar</option>
  <option  value="Chandigarh">Chandigarh</option>
  <option  value="Chhattisgarh">Chhattisgarh</option>
  <option  value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
  <option  value="Daman and Diu">Daman and Diu</option>
  <option  value="New Delhi">New Delhi</option>
  <option  value="Goa">Goa</option>
  <option  value="Gujarat">Gujarat</option>
  <option  value="Haryana">Haryana</option>
  <option  value="Himachal Pradesh">Himachal Pradesh</option>
  <option  value="Jammu and Kashmir">Jammu and Kashmir</option>
  <option  value="Jharkhand">Jharkhand</option>
  <option  value="Karnataka">Karnataka</option>
  <option  value="Kerala">Kerala</option>
  <option  value="Lakshadweep">Lakshadweep</option>
  <option  value="Madhya Pradesh">Madhya Pradesh</option>
  <option  value="Maharashtra">Maharashtra</option>
  <option  value="Manipur">Manipur</option>
  <option  value="Meghalaya">Meghalaya</option>
  <option  value="Mizoram">Mizoram</option>
  <option  value="Nagaland">Nagaland</option>
  <option  value="Odisha">Odisha</option>
  <option  value="Puducherry">Puducherry</option>
  <option  value="Punjab">Punjab</option>
  <option  value="Rajasthan">Rajasthan</option>
  <option  value="Sikkim">Sikkim</option>
  <option  value="Tamil Nadu">Tamil Nadu</option>
  <option  value="Telangana">Telangana</option>
  <option  value="Tripura">Tripura</option>
  <option  value="Uttar Pradesh">Uttar Pradesh</option>
  <option  value="Uttarakhand">Uttarakhand</option>
  <option  value="West Bengal">West Bengal</option>
  </select></td></td>
  </tr>
</tr>
 <tr>
      <td>PinCode:</td>
      <td><input type="text" name="c_pin"  class="input lettersonly required"   maxlength="6" /></td>
      </tr>
	  
	   </table>
	   <br>
	  <center><input type="submit" name="submit" value="Save" button class="w3-btn w3-round-large"></button></a>
	   <a href="javascript:void(0)" button class="w3-btn w3-round-large "tablink" onclick="openCity(event, 'quali');">Next</button></a></center><br>
  </div>
</div>
</form>

    <div id="quali" class="w3-container w3-border city">
    <div class="w3-container w3-section w3-border w3-topbar w3-bottombar w3-round-xlarge w3-border-red w3-margin-left w3-margin-right">
<div class="w3-panel w3-grey w3-round-xlarge">
<form method="post" action=''>
    <p>1.Academic Qualifications</p>
	</div>
	<table class="w3-table w3-striped w3-border">
    <tr>
	  <th>Type</th>
      <th>Examination/Degree</th>
      <th>Name of Institutuion</th>
	  <th>Board/University</th>
	  <th>Year of Passing</th>
	  <th>%/CGPA</th>
    </tr>
  <tr>
      <td>School</td>
      <td>10th</td>
      <td><input type="text" name="tschool"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="tboard"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="tpass"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="tcgpa"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td>School</td>
      <td>12th</td>
      <td><input type="text" name="ttschool"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="ttboard"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="ttpass"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="ttcgpa"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td>Graduate</td>
      <td><select class="w3-select" name="grad_option1" style="width:50%">
  <option value="Select">--Select--</option>
  <option  value="B.A.">B.A.</option>
  <option  value="B.B.A.">B.B.A.</option>
  <option  value="B.C.A.">B.C.A.</option>
  <option  value="B.Com">B.Com</option>
  <option  value="B.Ed.">B.Ed.</option>
  <option  value="B.Sc.">B.Sc.</option>
  </select></td>
      <td><input type="text" name="grad_school"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="grad_board"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="grad_pass"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="grad_cgpa"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td>Post Graduate</td>
      <td><select class="w3-select" name="pgrad_option1" style="width:50%">
  <option value="Select">--Select--</option>
  <option  value="M.A.">M.A.</option>
  <option  value="M.B.A.">M.B.A.</option>
  <option  value="M.C.A.">M.C.A.</option>
  <option  value="M.Com">M.Com</option>
  <option  value="M.Ed.">M.Ed.</option>
  <option  value="M.Sc.">M.Sc.</option>
  </select></td>
      <td><input type="text" name="pgrad_school1"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
	  <td><input type="text" name="pgrad_board1"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
	  <td><input type="text" name="pgrad_pass1"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="pgrad_cgpa1"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td></td>
      <td><select class="w3-select" name="pgrad_option2" style="width:50%">
 <option value="Select">--Select--</option>
  <option  value="M.A.">M.A.</option>
  <option  value="M.B.A.">M.B.A.</option>
  <option  value="M.C.A.">M.C.A.</option>
  <option  value="M.Com">M.Com</option>
  <option  value="M.Ed.">M.Ed.</option>
  <option  value="M.Sc.">M.Sc.</option>
  </select></td>
      <td><input type="text" name="pgrad_school2"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="pgrad_board2"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="pgrad_pass2"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="pgrad_cgpa2"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td></td>
      <td><select class="w3-select" name="pgrad_option3" style="width:50%">
 <option value="Select">--Select--</option>
  <option  value="M.A.">M.A.</option>
  <option  value="M.B.A.">M.B.A.</option>
  <option  value="M.C.A.">M.C.A.</option>
  <option  value="M.Com">M.Com</option>
  <option  value="M.Ed.">M.Ed.</option>
  <option  value="M.Sc.">M.Sc.</option>
  </select></td>
      <td><input type="text" name="pgrad_school3"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="pgrad_board3"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="pgrad_pass3"  class="input lettersonly required"   maxlength="4" /></td>
	  <td><input type="text" name="pgrad_cgpa3"  class="input lettersonly required"   maxlength="6" /></td>
    </tr>
	<tr>
      <td>Research Degree</td>
      <td><select class="w3-select" name="rd_option1" style="width:50%">
  <option value="Select">--Select--</option>
  <option  value="D.Litt.">D.Litt.</option>
  <option  value="D.Sc.">D.Sc.</option>
  <option  value="M.Phil.">M.Phil.</option>
  <option  value="Ph.D">Ph.D</option>
  <option  value="Post Doctoral">Post Doctoral</option>
  
  </select></td>
      <td><input type="text" name="rd_school1"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="rd_board1"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="rd_pass1"  class="input lettersonly required"   maxlength="4" /></td>
	  <td></td>
    </tr>
	<tr>
      <td></td>
      <td><select class="w3-select" name="rd_option2" style="width:50%">
  <option value="Select">--Select--</option>
  <option  value="D.Litt.">D.Litt.</option>
  <option  value="D.Sc.">D.Sc.</option>
  <option  value="M.Phil.">M.Phil.</option>
  <option  value="Ph.D">Ph.D</option>
  <option  value="Post Doctoral">Post Doctoral</option>
  
  </select></td>
      <td><input type="text" name="rd_school2"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="rd_board2"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	  <td><input type="text" name="rd_pass2"  class="input lettersonly required"   maxlength="4" /></td>
	 <td></td>
    </tr>
  </div>
  </table>
  <div class="w3-panel w3-grey w3-round-xlarge">
    <p>2.Extra Curricular Activities</p>
	</div>
	<td><textarea name="activities" rows="4" cols="130">
</textarea></td>

<div class="w3-panel w3-grey w3-round-xlarge">
    <p>3. Referees Details</p>
	</div>
	<table class="w3-table w3-striped w3-border">
    <tr>
	  <th>Name of Refree</th>
      <th>Designation</th>
      <th>Office Address </th>
	  <th>Tel. No.</th>
	  <th>Professional Relationship</th>
    </tr>
	<tr>
	<td><input type="text" name="first_ref"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
	<td><input type="text" name="first_desi"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
	<td><textarea name="first_office" rows="4" cols="20">
</textarea></td>
<td><input type="text" name="tel_first"  class="input lettersonly required"   maxlength="10" /></td>

<td><select class="w3-select" name="rfirst_option" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Ph.D. Supervisor">Ph.D. Supervisor</option>
  <option  value="Teacher at PG level">Teacher at PG level</option>
  <option  value="Research Collaborator">Research Collaborator</option>
  <option  value="Senior Associate">Senior Associate</option>
  </select></td>
	</tr>
	 </tr>
	<tr>
	<td><input type="text" name="second_ref"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><input type="text" name="second_desi"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><textarea name="second_office" rows="4" cols="20">
</textarea></td>
<td><input type="text" name="tel_second"  class="input lettersonly required"   maxlength="10" /></td>

<td><select class="w3-select" name="rsecond_option" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Ph.D. Supervisor">Ph.D. Supervisor</option>
  <option  value="Teacher at PG level">Teacher at PG level</option>
  <option  value="Research Collaborator">Research Collaborator</option>
  <option  value="Senior Associate">Senior Associate</option>
  </select></td>
	</tr>
	 </tr>
	<tr>
	<td><input type="text" name="third_ref"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><input type="text" name="third_desi"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><textarea name="third_office" rows="4" cols="20">
</textarea></td>
<td><input type="text" name="tel_third"  class="input lettersonly required"   maxlength="10" /></td>

<td><select class="w3-select" name="rthird_option" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Ph.D. Supervisor">Ph.D. Supervisor</option>
  <option  value="Teacher at PG level">Teacher at PG level</option>
  <option  value="Research Collaborator">Research Collaborator</option>
  <option  value="Senior Associate">Senior Associate</option>
  </select></td>
	</tr>
	</div>
	</div>
	</table>
<br>
	  <center><input type="submit" name="submitaca" value="Save" button class="w3-btn w3-round-large"></button></a>
	   <a href="javascript:void(0)" button class="w3-btn w3-round-large "tablink" onclick="openCity(event, 'work');">Next</button></a></center><br>
</div>
</div>
</form>

  <div id="work" class="w3-container w3-border city">
     <div class="w3-container w3-section w3-border w3-topbar w3-bottombar w3-round-xlarge w3-border-red w3-margin-left w3-margin-right">
<div class="w3-panel w3-grey w3-round-xlarge">
    <p>1.Employment Details</p>
	</div>
	<table class="w3-table w3-striped w3-border">
    <tr>
	  <th>Organization Name</th>
      <th>Status of Organization</th>
      <th>Designation</th>
	  <th>Period of Work<br>(in months)</th>
	  <th>Nature of Pay</th>
	  <th>Gross Pay</th>
    </tr>
	<tr>
	<td><input type="text" name="org_namefirst"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><select class="w3-select" name="status_orgfirst" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Govt.">Govt.</option>
  <option  value="Semi Govt.">Semi Govt.</option>
  <option  value="Autonomous">Autonomous</option>
  <option  value="Private">Private</option>
  </select></td>
  
  <td><input type="text" name="org_desifirst"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><input type="text" name="org_pworkfirst"  class="input lettersonly required"  style="text-transform:uppercase" maxlength="60" /></td>
  <td><select class="w3-select" name="org_npayfirst" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Graded Salary">Graded Salary</option>
  <option  value="Consoliated Salary">Consoliated Salary</option>
  <option  value="Honorarium">Honorarium</option>
  <option  value="Job Basis">Job Basis</option>
  
  </select></td>
  <td><input type="text" name="org_gpayfirst"  class="input lettersonly required"   maxlength="60" /></td>
  
  
	</tr>
	<tr>
	<td><input type="text" name="org_namesecond"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
	<td><select class="w3-select" name="status_orgsecond" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Govt.">Govt.</option>
  <option  value="Semi Govt.">Semi Govt.</option>
  <option  value="Autonomous">Autonomous</option>
  <option  value="Private">Private</option>
  </select></td>
  <td><input type="text" name="org_desisecond"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><input type="text" name="org_pworksecond"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><select class="w3-select" name="org_npaysecond" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Graded Salary">Graded Salary</option>
  <option  value="Consoliated Salary">Consoliated Salary</option>
  <option  value="Honorarium">Honorarium</option>
  <option  value="Job Basis">Job Basis</option>
  
  </select></td>
  <td><input type="text" name="org_gpaysecond"  class="input lettersonly required"   maxlength="60" /></td>
	</tr>
	
	
	<tr>
	<td><input type="text" name="org_namethird"  class="input lettersonly required"   maxlength="60" /></td>
	<td><select class="w3-select" name="status_orgthird" style="width:80%">
 <option value="Select">--Select--</option>
  <option  value="Govt.">Govt.</option>
  <option  value="Semi Govt.">Semi Govt.</option>
  <option  value="Autonomous">Autonomous</option>
  <option  value="Private">Private</option>
  </select></td>
  <td><input type="text" name="org_desithird"  class="input lettersonly required"   maxlength="60" /></td>
  <td><input type="text" name="org_pworkthird"  class="input lettersonly required"   maxlength="60" /></td>
  <td><select class="w3-select" name="org_npaythird" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="Graded Salary">Graded Salary</option>
  <option  value="Consoliated Salary">Consoliated Salary</option>
  <option  value="Honorarium">Honorarium</option>
  <option  value="Job Basis">Job Basis</option>
  
  </select></td>
  <td><input type="text" name="org_gpaythird"  class="input lettersonly required"   maxlength="60" /></td>
	</tr>
	</table>
	<div class="w3-panel w3-grey w3-round-xlarge">
    <p>2.Details of Professional Recognitions, Awards, Fellowship, Scholarship, Medal, Prize, Honours Recieved :</p>
	</div>
	<table class="w3-table w3-striped w3-border">
    <tr>
	  <th>Award Type</th>
      <th>Award Name</th>
      <th>Awarding Institutuion or Body</th>
	  <th>Date</th>
    </tr>
	<tr>
	<td><select class="w3-select" name="atype_first" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="International">International</option>
  <option  value="National">National</option>
  <option  value="State">State</option>
  <option  value="Local">Local</option>
  <option  value="International Level">International Level</option>
  </select></td>
  <td><input type="text" name="aname_first"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><input type="text" name="abody_first"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td>
  <input type="date" name="dob_first">
  
</td>
	</tr>
	<tr>
	<td><select class="w3-select" name="atype_second" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="International">International</option>
  <option  value="National">National</option>
  <option  value="State">State</option>
  <option  value="Local">Local</option>
  <option  value="International Level">International Level</option>
  </select></td>
  <td><input type="text" name="aname_second"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><input type="text" name="abody_second"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td>
  <input type="date" name="dob_second">
  
</td>
	</tr>
	<tr>
	<td><select class="w3-select" name="atype_third" style="width:80%">
  <option value="Select">--Select--</option>
  <option  value="International">International</option>
  <option  value="National">National</option>
  <option  value="State">State</option>
  <option  value="Local">Local</option>
  <option  value="International Level">International Level</option>
  </select></td>
  <td><input type="text" name="aname_third"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td><input type="text" name="abody_third"  class="input lettersonly required" style="text-transform:uppercase"  maxlength="60" /></td>
  <td>
  <input type="date" name="dob_third">
  
</td>
	</tr>
	</table>
  <div class="w3-panel w3-grey w3-round-xlarge">
    <p>3.Additional Information(Max.1000 words)</p>
	</div>
	<td><textarea rows="4" cols="130">
</textarea></td>
<center> <p><a href="javascript:void(0)" button class="w3-btn w3-round-large "tablink" onclick="openCity(event, 'declaration');">Next</button></a></p></center>
	</div>
  </div>
  
  <div id="declaration" class="w3-container w3-border city">
    
  </div>


<script>
function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}
</script>

</body>
</html>

</body>
</html>

