-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2016 at 05:59 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE `general` (
  `user_id` int(11) NOT NULL,
  `user_first_name` varchar(30) NOT NULL,
  `user_middle_name` varchar(20) NOT NULL,
  `user_last_name` varchar(20) NOT NULL,
  `post` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `father_first_name` varchar(20) NOT NULL,
  `father_middle_name` varchar(20) NOT NULL,
  `father_last_name` varchar(20) NOT NULL,
  `mother_first_name` varchar(20) NOT NULL,
  `mother_middle_name` varchar(20) NOT NULL,
  `mother_last_name` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `nationality` varchar(10) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `martial` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `handicaped` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` int(10) NOT NULL,
  `paddress1` varchar(50) NOT NULL,
  `paddress2` varchar(50) NOT NULL,
  `paddress3` varchar(50) NOT NULL,
  `pcountry` varchar(20) NOT NULL,
  `pstate` varchar(30) NOT NULL,
  `ppin` int(6) NOT NULL,
  `caddress1` varchar(50) NOT NULL,
  `caddress2` varchar(50) NOT NULL,
  `caddress3` varchar(50) NOT NULL,
  `ccountry` varchar(20) NOT NULL,
  `cstate` varchar(30) NOT NULL,
  `cpin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`user_id`, `user_first_name`, `user_middle_name`, `user_last_name`, `post`, `department`, `father_first_name`, `father_middle_name`, `father_last_name`, `mother_first_name`, `mother_middle_name`, `mother_last_name`, `dob`, `nationality`, `religion`, `gender`, `martial`, `category`, `handicaped`, `email`, `mobile`, `paddress1`, `paddress2`, `paddress3`, `pcountry`, `pstate`, `ppin`, `caddress1`, `caddress2`, `caddress3`, `ccountry`, `cstate`, `cpin`) VALUES
(5, 'MANISH', '', 'SINGH', 'HOD', 'School of Engineering & Technology', 'surendra', '', 'singh', 'savitri', '', 'devi', '1993-01-20', 'indian', 'Hinduism', 'male', 'single', 'obc', 'NO', 'manniamc@gmail.com', 2147483647, 'ROOM NO:47,KABIRDAS HOSTEL,PONDICHERRY UNIVERSITY', 'R.V.NAGAR KALPET', 'PUDUCHERRY', 'india', 'Puducherry', 605014, 'C/O SUDHA LAL', 'ANAND NAGAR KAJU BAGAN HEHAL', 'RANCHI', 'india', 'Jharkhand', 834005),
(6, 'C ', 'SHASHI narayan', 'rao', 'HOD', 'School of Engineering & Technology', 'C', 'KESHAV', 'RAO', 'c', 'nagmani', '', '1992-06-15', 'indian', 'Hinduism', 'male', 'single', 'general', '', 'shashirao15@gmail.com', 2147483647, 'h.no.-200,vill-tamulia,', 'p.o.-pardih,p.s.-chandil,', 'jamshedpur', 'india', 'Jharkhand', 831012, 'ROOM NO-38,maka HOSTEL,PONDICHERRY UNIVERSITY', 'R.V.NAGAR, KALAPET', 'pondicherry', 'india', 'Puducherry', 605014);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `general`
--
ALTER TABLE `general`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `general`
--
ALTER TABLE `general`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
