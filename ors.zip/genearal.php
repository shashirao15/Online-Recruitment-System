<?php
mysql_connect("localhost","root","");
mysql_select_db("users_db");

if(isset($_POST['submit'])) {
	$user_first_name = $_POST['first_name'];
	$user_middle_name = $_POST['middle_name'];
	$user_last_name = $_POST['last_name'];
	$post = $_POST['option_pa'];
	$department = $_POST['option_dept'];
	$father_first_name = $_POST['ffirst_name'];
	$father_middle_name = $_POST['fmiddle_name'];
	$father_last_name = $_POST['flast_name'];
	$mother_first_name = $_POST['mfirst_name'];
	$mother_middle_name = $_POST['mmiddle_name'];
	$mother_last_name = $_POST['mlast_name'];
	$dob = $_POST['dob'];
	$nationality = $_POST['nationality'];
	$religion = $_POST['option_religion'];
	$gender = $_POST['gender'];
	$martial = $_POST['martial'];
	$category = $_POST['category'];
	$handicaped = $_POST['option_php'];
	$email = $_POST['email_add'];
	$mobile = $_POST['mnumber'];
	$paddress1 = $_POST['pline1'];
	$paddress2 = $_POST['pline2'];
	$paddress3 = $_POST['pline3'];
	$pcountry = $_POST['p_country'];
	$pstate = $_POST['p_state'];
	$ppin = $_POST['p_pin'];
	$caddress1 = $_POST['cline1'];
	$caddress2 = $_POST['cline2'];
	$caddress3 = $_POST['cline3'];
	$ccountry = $_POST['c_country'];
	$cstate = $_POST['c_state'];
	$cpin = $_POST['c_pin'];
	
	$query = "insert into general (user_first_name,user_middle_name,user_last_name,post,department,father_first_name,father_middle_name,father_last_name,mother_first_name,mother_middle_name,mother_last_name,dob,nationality,religion,gender,martial,category,handicaped,email,mobile,paddress1,paddress2,paddress3,pcountry,pstate,ppin,caddress1,caddress2,caddress3,ccountry,cstate,cpin) values ('$user_first_name','$user_middle_name','$user_last_name','$post','$department','$father_first_name','$father_middle_name','$father_last_name','$mother_first_name','$mother_middle_name','$mother_last_name','$dob','$nationality','$religion','$gender','$martial','$category','$handicaped','$email','$mobile','$paddress1','$paddress2','$paddress3','$pcountry','$pstate','$ppin','$caddress1','$caddress2','$caddress3','$ccountry','$cstate','$cpin')";
	if(mysql_query($query)){
			
			echo "<script>alert('Data have been Saved Successfully!')</script>";
		}
		}
?> 
		
	