<?php
mysql_connect("localhost","root","");
mysql_select_db("users_db");

if(isset($_POST['submitaca'])) {
	$ten_school = $_POST['tschool'];
	$ten_board = $_POST['tboard'];
	$ten_pass = $_POST['tpass'];
	$ten_marks = $_POST['tcgpa'];
	$twelve_school = $_POST['ttschool'];
	$twelve_board = $_POST['ttboard'];
	$twelve_pass = $_POST['ttpass'];
	$twelve_marks = $_POST['ttcgpa'];
	$graduate_course = $_POST['grad_option1'];
	$graduate_college = $_POST['grad_school'];
	$graduate_univ = $_POST['grad_board'];
	$graduate_pass = $_POST['grad_pass'];
	$graduate_marks = $_POST['grad_cgpa'];
	$pg_course1 = $_POST['pgrad_option1'];
	$pg_college1 = $_POST['pgrad_school1'];
	$pg_univ1 = $_POST['pgrad_board1'];
	$pg_pass1 = $_POST['pgrad_pass1'];
	$pg_marks1 = $_POST['pgrad_cgpa1'];
	$pg_course2 = $_POST['pgrad_option2'];
	$pg_college2 = $_POST['pgrad_school2'];
	$pg_univ2 = $_POST['pgrad_board2'];
	$pg_pass2 = $_POST['pgrad_pass2'];
	$pg_marks2 = $_POST['pgrad_cgpa2'];
	$pg_course3 = $_POST['pgrad_option3'];
	$pg_college3 = $_POST['pgrad_school3'];
	$pg_univ3 = $_POST['pgrad_board3'];
	$pg_pass3 = $_POST['pgrad_pass3'];
	$pg_marks3 = $_POST['pgrad_cgpa3'];
	$rd_course1 = $_POST['rd_option1'];
	$rd_college1 = $_POST['rd_school1'];
	$rd_univ1 = $_POST['rd_board1'];
	$rd_pass1 = $_POST['rd_pass1'];
	$rd_course2 = $_POST['rd_option2'];
	$rd_college2 = $_POST['rd_school2'];
	$rd_univ2 = $_POST['rd_board2'];
	$rd_pass2 = $_POST['rd_pass2'];
	$activities = $_POST['activities'];
	$refree_name1 = $_POST['first_ref'];
	$refree_degn1 = $_POST['first_desi'];
	$refree_office1 = $_POST['first_office'];
	$refree_contact1 = $_POST['tel_first'];
	$refree_relation1 = $_POST['rfirst_option'];
	$refree_name2 = $_POST['second_ref'];
	$refree_degn2 = $_POST['second_desi'];
	$refree_office2 = $_POST['second_office'];
	$refree_contact2 = $_POST['tel_second'];
	$refree_relation2 = $_POST['rsecond_option'];
	$refree_name3 = $_POST['third_ref'];
	$refree_degn3 = $_POST['third_desi'];
	$refree_office3 = $_POST['third_office'];
	$refree_contact3 = $_POST['tel_third'];
	$refree_relation3 = $_POST['rthird_option'];
	
	$query = "insert into qualification (ten_school,ten_board,ten_pass,ten_marks,twelve_school,twelve_board,twelve_pass,twelve_marks,graduate_course,graduate_college,graduate_univ,graduate_pass,graduate_marks,pg_course1,pg_college1,pg_univ1,pg_pass1,pg_marks1,pg_course2,pg_college2,pg_univ2,pg_pass2,pg_marks2,pg_course3,pg_college3,pg_univ3,pg_pass3,pg_marks3,rd_course1,,rd_college1,rd_univ1,rd_pass1,rd_course2,rd_college2,rd_univ2,rd_pass2,activities,refree_name1,refree_degn1,refree_office1,refree_contact1,refree_relation1,refree_name2,refree_degn2,refree_office2,refree_contact2,refree_relation2,refree_name3,refree_degn3,refree_office3,refree_contact3,refree_relation3) values ('$ten_school','$ten_board','$ten_pass','$ten_marks','$twelve_school','$twelve_board','$twelve_pass','$twelve_marks','$graduate_course','$graduate_college','$graduate_univ','$graduate_pass','$graduate_marks','$pg_course1','$pg_college1','$pg_univ1','$pg_pass1','$pg_marks1','$pg_course2','$pg_college2','$pg_univ2','$pg_pass2','$pg_marks2','$pg_course3','$pg_college3','$pg_univ3','$pg_pass3','$pg_marks3','$rd_course1','$rd_college1','$rd_univ1','$rd_pass1','$rd_course2','$rd_college2','$rd_univ2','$rd_pass2','$activities','$refree_name1','$refree_degn1','$refree_office1','$refree_contact1','$refree_relation1','$refree_name2','$refree_degn2','$refree_office2','$refree_contact2','$refree_relation2','$refree_name3','$refree_degn3','$refree_office3','$refree_contact3','$refree_relation3')";
	
	
	if(mysql_query($query)){
			
			echo "<script>alert('Data have been Saved Successfully!')</script>";
		}
		}
		?> 
	
	
	