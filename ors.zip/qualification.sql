-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2016 at 05:59 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `ten_school` varchar(50) NOT NULL,
  `ten_board` varchar(50) NOT NULL,
  `ten_pass` int(10) NOT NULL,
  `ten_marks` varchar(10) NOT NULL,
  `twelve_school` varchar(50) NOT NULL,
  `twelve_board` varchar(50) NOT NULL,
  `twelve_pass` int(10) NOT NULL,
  `twelve_marks` varchar(10) NOT NULL,
  `graduate_course` varchar(30) NOT NULL,
  `graduate_college` varchar(50) NOT NULL,
  `graduate_univ` varchar(50) NOT NULL,
  `graduate_pass` int(10) NOT NULL,
  `graduate_marks` varchar(10) NOT NULL,
  `pg_course1` varchar(50) NOT NULL,
  `pg_college1` varchar(50) NOT NULL,
  `pg_univ1` varchar(50) NOT NULL,
  `pg_pass1` int(10) NOT NULL,
  `pg_marks1` varchar(10) NOT NULL,
  `pg_course2` varchar(50) NOT NULL,
  `pg_college2` varchar(50) NOT NULL,
  `pg_univ2` varchar(50) NOT NULL,
  `pg_pass2` int(10) NOT NULL,
  `pg_marks2` varchar(10) NOT NULL,
  `pg_course3` varchar(50) NOT NULL,
  `pg_college3` varchar(50) NOT NULL,
  `pg_univ3` varchar(50) NOT NULL,
  `pg_pass3` int(10) NOT NULL,
  `pg_marks3` varchar(10) NOT NULL,
  `rd_course1` varchar(50) NOT NULL,
  `rd_college1` varchar(50) NOT NULL,
  `rd_univ1` varchar(50) NOT NULL,
  `rd_pass1` int(10) NOT NULL,
  `rd_course2` varchar(50) NOT NULL,
  `rd_college2` varchar(50) NOT NULL,
  `rd_univ2` varchar(50) NOT NULL,
  `rd_pass2` int(10) NOT NULL,
  `activities` varchar(1000) NOT NULL,
  `refree_name1` varchar(50) NOT NULL,
  `refree_degn1` varchar(30) NOT NULL,
  `refree_office1` varchar(100) NOT NULL,
  `refree_contact1` int(10) NOT NULL,
  `refree_relation1` varchar(30) NOT NULL,
  `refree_name2` varchar(50) NOT NULL,
  `refree_degn2` varchar(30) NOT NULL,
  `refree_office2` varchar(100) NOT NULL,
  `refree_contact2` int(10) NOT NULL,
  `refree_relation2` varchar(30) NOT NULL,
  `refree_name3` varchar(50) NOT NULL,
  `refree_degn3` varchar(30) NOT NULL,
  `refree_office3` varchar(100) NOT NULL,
  `refree_contact3` int(10) NOT NULL,
  `refree_relation3` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
