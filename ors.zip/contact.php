<?php

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Contact Form</title>
   
<link rel="stylesheet" href="css/w3.css">
   
</head>
<hgroup>
<style>
h1 {text-align: center;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
      <h3><b><span style="color:blue;">(Teaching Staff)</span> </b> </h3>         

</hgroup>
<style>
h3{text-align: center;}
h2{text-align: center;}
</style>


<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> </hgroup>
<body>
<div class="w3-down">
  <div class="w3-row w3-padding w3-white">
    <div class="w3-col s3">
      <a href="index.php" class="w3-btn-block w3-hover-red">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="notice.php" class="w3-btn-block w3-hover-red">NOTICE</a>
    </div>
    <div class="w3-col s3">
      <a href="carrer.php" class="w3-btn-block w3-hover-red">CARRERS</a>
    </div>
    <div class="w3-col s3">
      <a href="contact.php" class="w3-btn-block w3-hover-red">CONTACT</a>
    </div>
  </div>
</div>

<!-- Contact -->
  <div class="w3-center w3-padding-64" id="contact">
    <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Contact Us</span>
  </div>

  <form class="w3-container">
    <div class="w3-group">
       <center><input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Name"></center>
    </div>
    <div class="w3-group">
    
       <center><input class="w3-input w3-border w3-hover-border-black" style="width:50%" type="text"placeholder="Email"></center>
    </div>
    <div class="w3-group">
     
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%"type="text"placeholder="Subject"></center>
    </div>
	<div class="w3-group">
     
      <center> <input class="w3-input w3-border w3-hover-border-black" style="width:50%"type="text"placeholder="Message"></center>
    </div>
	
    <center> <button type="button" class="w3-btn w3-btn-block w3-padding-12"style="width:50%">Send</button></center>
  </form>


</body>
</html>