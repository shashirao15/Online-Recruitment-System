<!DOCTYPE html>
<html>
<head>
<title>Text Input Control</title>
</head>
<body>
<?php

mysql_connect("localhost","root","");
mysql_select_db("users_db");

if(isset($_POST['submit'])) {
	$user_fname = $_POST['first_name'];
	$user_lname = $_POST['last_name'];
	$user_password = $_POST['password'];
	$user_desc = $_POST['description'];
	$user_subject = $_POST['subject'];
	$user_subjects = $_POST['dropdown'];
	$user_dob = $_POST['dob'];
	
	
	
	$query = "insert into sample (first_name,last_name,password,description,subject,dropdown,dob) values ('$user_fname','$user_lname','$user_password','$user_desc','$user_subject','$user_subjects','$user_dob')";
		if(mysql_query($query)){
			
			echo "<script>alert('Data have been Saved Successfully!')</script>";
		}
		}
		?> 
		

<p><span class="error">* required field.</span></p>
<form method='post' action='sample.php' >
First name:  <input type="text" name="first_name" />
<br><br><br>
Last name:  <input type="text" name="last_name" />
<br><br><br>
Password:  <input type="password" name="password" />
<br><br><br>
Description : <br />
<textarea rows="5" cols="50" name="description">
</textarea>
<br><br><br>
<input type="radio" name="subject" value="maths"> Maths
<input type="radio" name="subject" value="physics"> Physics
<br><br><br>
<select name="dropdown">
<option value="Maths">Maths</option>
<option value="Physics">Physics</option>
</select>
<br><br><br>


Date of birth:<input type="date" name="dob">
<br><br><br>
<input type="submit" name="submit" value="Save" />

</form>
</body>
</html>

