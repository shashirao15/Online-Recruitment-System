<?php

?>
<html>
<head>
<title>TESTING </title>
</head>
 <meta charset="UTF-8">
   <link rel="stylesheet" href="css/w3.css"> 
	
<body>


<div id="wrapper">

    <header id="header" class="clearfix" role="banner">
    
<hgroup>
<style>
h1 {text-align: center;}
h2 {text-align: center;}
h3 {text-align: center;}
h3 {text-align: center;}
.city {display:none;}
</style>
 <h1><b><span style="color:#008000;font-size: 140%">Online Recruitment System <span style="color:#008000;font-size: 100%">(ORS)</span> </span></b></h1>
 <h3><b><span style="color:blue;">(Teaching Staff)</span> </b> </h3>           
</hgroup>

<hgroup>
<h2><b><span style="color:#FF0000;">Pondicherry University</span> </b> </h2> 
</hgroup>
<body>



<div class="w3-down">
  <div class="w3-row w3-padding w3-white">
    <div class="w3-col s3">
      <a href="index.php" class="w3-btn-block w3-hover-red">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="notice.php" class="w3-btn-block w3-hover-red">NOTICE</a>
    </div>
    <div class="w3-col s3">
      <a href="carrer.php" class="w3-btn-block w3-hover-red">CARRERS</a>
    </div>
    <div class="w3-col s3">
      <a href="contact.php" class="w3-btn-block w3-hover-red">CONTACT</a>
    </div>
  </div>
</div>

<div class="w3-content w3-display-container">

<a class="w3-btn-floating w3-hover-dark-grey w3-display-left" onclick="plusDivs(-1)">&#10094;</a>
<a class="w3-btn-floating w3-hover-dark-grey w3-display-right" onclick="plusDivs(1)">&#10095;</a>

<div class="w3-display-container mySlides">
  <img src="images/3.jpg" width="980" height="450">
  <div class="w3-large w3-container w3-padding-20 w3-black">
    
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/11.jpg" width="980" height="450">
  <div class="w3-large w3-container w3-padding-20 w3-black">
    
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/4.jpg" width="980" height="450">
  <div class="w3-large w3-container w3-padding-20 w3-black">
    
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/5.jpg" width="980" height="450">
  <div class="w3-large w3-container w3-padding-20 w3-black">
    
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/8.jpg" width="980" height="450">
  <div class="w3-large w3-container w3-padding-20 w3-black">
  </div>
</div>

</div>
 <div class="w3-container w3-content w3-center w3-padding-54" style="max-width:1000px" id="band">
<hgroup>
<h4><b><u><span style="color:gray;">About University</span></u></b></h4> 
</hgroup>
                 <p class="w3-justify"><b><span style="color:gray; font-size:110%">Pondicherry University is a Central University established by an Act of Parliament
in October 1985. It is an affiliating University with a jurisdiction spread over the Union Territory of Puducherry,
Lakshwadeep and Andaman and Nicobar Islands.
The University's objectives are to disseminate and advance knowledge by offering teaching and research facilities, to
make provisions for studies in French and integrated courses in Humanities and the Sciences, and to promote interdisciplinary
studies and research. The University's motto is "Vers la lumière" meaning "towards the light" The main
campus is located at Kalapet, 10 km from the town of Puducherry, in a serene and beautiful campus of 800 acres
adjoining the scenic Bay of Bengal.
The University also has campuses at Karaikal and Port Blair which currently offer P.G. and Doctoral programmes.
The University has entered into MoUs with a good number of reputed International Institutions in India and abroad for
collaboration and faculty development.
The salient features of the University include:<br>
* Add-On Courses.<br>
* Remedial coaching for weaker section students.<br>
* Fee waiver for differently abled students.<br>
In addition, the University Placement Cell has MoU with reputed firms.</b></p></span>

</body>
</html>
<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}
</script>

</body>
</html>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>